## ---- message = FALSE----------------------------------------------------
# set seed
set.seed(3672)

library(forestRK)
library(mlbench)

## ----setup, echo = TRUE--------------------------------------------------
data(Soybean)
dim(Soybean)
levels(Soybean$Class)
head(Soybean)
summary(Soybean)

## ---- echo = TRUE--------------------------------------------------------
# Step 1: Remove all NA's and NaN's from the original dataset
Soybean <- na.omit(Soybean)

# Step 2: Seperate the dataset into a chunk that stores covariates of both 
# training and test observations X and a vector y that stores class types of the 
# training observations
vec <- seq.int(1,562, by=3) # indices of the training observations
X <- Soybean[,2:36]
y <- Soybean[vec,1]

# Step 3: Numericize the data frame X by applying the x.organizer function
# and split X into a training and a test set
X1 <- x.organizer(X, encoding = "bin") # Binary Encoding applied
X2 <- x.organizer(X, encoding = "num") # Numeric Encoding applied

## train and test set from the Binary Encoding
x.train1 <- X1[vec,]
x.test1 <- X1[-vec,]

## train and test set from the Numeric Encoding
x.train2 <- X2[vec,]
x.test2 <- X2[-vec,]

# Step 4: Numericize the vector y by applying the y.organizer function
y.train <- y.organizer(y)$y.new # a vector storing the numericized class type
y.factor.levels <- y.organizer(y)$y.factor.levels

## ---- eval = FALSE-------------------------------------------------------
#  
#      ## Numercize the data frame of covariates via Binary Encoding
#  
#      if(encoding == "bin"){
#          ## x.dat is the data frame containing the covariates of both training and test observations,
#          ## x.dat is one of the required input to call the x.organizer function
#          x.new <- rep(0, dim(x.dat)[1])
#          n.cov <- dim(x.dat)[2]
#          for(j in 1:n.cov){
#      		    if(!(is.factor(x.dat[,j]) || is.character(x.dat[,j]))){
#      		        x.new <- data.frame(x.new, x.dat[,j])
#      	         	colnames(x.new)[dim(x.new)[2]] <- colnames(x.dat)[j]
#      		    } # if all of the covariates in the dataset are not categorical,
#                # then the function will simply return the original numeric dataset.
#  
#      		    else if(is.factor(x.dat[,j]) || is.character(x.dat[,j])){
#      			      x.bin  <- data.frame(matrix(as.integer(intToBits(as.integer(as.factor(x.dat[,j])))), ncol = 32,
#      			                           nrow = length(x.dat[,j]),byrow = TRUE)[ ,1:ceiling(log(length(unique(x.dat[,j])) + 1)/log(2))])
#      			      colnames(x.bin) <- paste(colnames(x.dat)[j], c(1:(dim(x.bin)[2])))
#      			      x.new <- data.frame(x.new, x.bin)
#      		    } # end of else if(is.factor(x.dat[,j]) || is.character(x.dat[,j]))
#          } # end of for(j in 1:n.cov)
#  
#          x.new <- x.new[,-1]

## ---- eval = FALSE-------------------------------------------------------
#      else if(encoding == "num"){
#          ## Convert the original data frame of covariates into a numericized one via Numeric Encoding
#          ## Numeric Encoding simply assigns an arbitrary number to each class category
#          x.new <- data.frame(data.matrix(x.dat))
#      }

## ---- results = "hold"---------------------------------------------------
tree.gini <- construct.treeRK(x.train1, y.train, min.num.obs.end.node.tree = 6, 
                              entropy = FALSE)

## ---- results = "hold"---------------------------------------------------
## default for entropy is TRUE
## default for min.num.obs.end.node.tree is 5
tree.entropy <- construct.treeRK(x.train2, y.train)

## ---- echo = TRUE--------------------------------------------------------
tree.gini$flag 

## ----fig_simple_plot, echo = TRUE, fig.align = "center", fig.width = 14, fig.height = 8----
## plotting the tree.gini rkTree obtained via construct.treeRK function
draw.treeRK(tree.gini, y.factor.levels, font="Times", node.colour = "white", 
            text.colour = "dark blue", text.size = 0.6, tree.vertex.size = 30, 
            tree.title = "Decision Tree", title.colour = "dark green")

## ---- echo = TRUE, eval = FALSE------------------------------------------
#      ## Make edges
#      for(i in 1:(length(f)-1)){
#          branch <- f[i]
#  
#          for (j in (i+1):(length(f))){
#              ch <- f[j]
#              if ((substr(ch,1,nchar(branch))==branch) && (nchar(ch)==(nchar(branch)+1))){ed <- c(ed,i,j)}
#          }
#      }
#  
#      # creating empty graph (i.e. a graph with no edges)
#      i.graph <- make_empty_graph(length(unlist(tr$flag)), directed = T)
#      # adding edges onto the empty graph
#      i.graph <- add_edges(i.graph, ed)

## ---- echo = TRUE--------------------------------------------------------
## display numericized predicted class type for the first 5 observations (in the 
## order of increasing original observation index number) from the test set with
## Binary Encoding
prediction.df <- pred.treeRK(X = x.test1, tree.gini)$prediction.df
prediction.df[1:5, dim(prediction.df)[2]]

## display the list of hierarchical flag from the test set with Numeric Encoding
pred.treeRK(X = x.test2, tree.entropy)$flag.pred

## ---- echo = TRUE--------------------------------------------------------
## make a forestRK model based on the training data with Binary Encoding and with Gini Index as the splitting criteria
## normally nbags and samp.size would be much larger than 30 and 50
forestRK.1 <- forestRK(x.train1, y.train, nbags = 30, samp.size = 50, entropy = FALSE)

## make a forestRK model based on the training data with Numeric Encoding and with Entropy as the splitting criteria
## make a forestRK model based on the training data with Binary Encoding and with Gini Index as the splitting criteria
## normally nbags and samp.size would be much larger than 30 and 50
forestRK.2 <- forestRK(x.train2, y.train, nbags = 30, samp.size = 50)

## ---- echo = TRUE--------------------------------------------------------
# make predictions on the test set x.test1 based on the forestRK model constructed from
# x.train1 and y.train (recall: these are the training data with Binary Encoding)
# after using Gini Index as splitting criteria (entropy == FALSE)
pred.forest.rk1 <- pred.forestRK(x.test = x.test1, x.training = x.train1, 
                                 y.training = y.train, nbags = 100, 
                                samp.size = 100, y.factor.levels = y.factor.levels,
                                entropy = FALSE)

# make predictions on the test set x.test2 based on the forestRK model constructed from
# x.train2 and y.train (recall: these are the training data with Numeric Encoding)
# after using Entropy as splitting criteria (entropy == TRUE)
pred.forest.rk2 <- pred.forestRK(x.test = x.test2, x.training = x.train2, 
                                 y.training = y.train, nbags = 100, 
                                 samp.size = 100, y.factor.levels = y.factor.levels, 
                                 entropy = TRUE)

## ---- echo = TRUE, eval = FALSE------------------------------------------
#  ## get tree
#  tree.index.ex <- c(1,3,8)
#  # extract information about the 1st, 3rd, and 8th tree in the forestRK.1
#  get.tree <- get.tree.forestRK(forestRK.1, tree.index = tree.index.ex)
#  # display 8th tree in the forest (which is the third element of the vector 'tree.index.ex')
#  get.tree[["8"]]
#  
#  ## get the list of variable used for splitting
#  covariate.used.for.split.tree <- var.used.forestRK(forestRK.1, tree.index = c(4,5,6))
#  # get the list of names of covariates used for splitting to construct tree #6 in the forestRK.1
#  covariate.used.for.split.tree[["6"]]

## ---- echo = TRUE, fig.align = "center", fig.width = 12, fig.height = 6----
## Generate 2-dimensional MDS plot of the test observations colour coded by the 
## predictions stored under the object pred.forest.rk1
mds.plot.forestRK(pred.forest.rk1, plot.title = "My Title", xlab ="1st Coordinate", 
                  ylab = "2nd Coordinate", colour.lab = "Predictions By The forestRK.1")

## ---- echo = TRUE, eval = TRUE-------------------------------------------
## Generate 2-dimensional MDS plot of the test observations colour coded by the 
## predictions stored under the object pred.forest.rk1
imp <- importance.forestRK(forestRK.1)

# gives the list of covariate names ordered from most important to least important
covariate.names <- imp$importance.covariate.names 

# gives the list of average decrease in (weighted) node impurity across all trees in the forest
# ordered from the highest to lowest in value.
# that is, the first element of this vector pertains to the first covariate listed under
# imp$importance.covariate.names 
ave.decrease.criteria <- imp$average.decrease.in.criteria.vec

## ---- echo = TRUE, fig.align = "center", fig.width = 12, fig.height = 6----
## Generate importance plot of the forestRK.1 object
p <- importance.plot.forestRK(imp, colour.used="dark green", fill.colour="dark green", label.size=8)

p

## ---- fig.align = "center", fig.width = 12, fig.height = 6, echo = TRUE----
## overall prediction accuracy (in percentage) when training data was modified with Binary Encoding
## and the Gini Index was used as splitting criteria.
y.test <- Soybean[-vec,1]
sum(as.vector(pred.forest.rk1$pred.for.obs.forest.rk) == as.vector(y.test)) * 100 / length(y.test)

## overall prediction accuracy (in percentage) when training data was modified with numeric Encoding
## and the Entropy was used as splitting criteria.
y.test <- Soybean[-vec,1]
sum(as.vector(pred.forest.rk2$pred.for.obs.forest.rk) == as.vector(y.test)) * 100 / length(y.test)

### NOTE: IF YOU SHUFFLED THE DATA before dividing them into a training and a test
###       set, since the observations in pred.forest.rk1 and pred.forest.rk2 are
###       re-ordered by the increasing original observation index number,
###       the order of the test data points presented in pred.forest.rk objects
###       may not be same as the shuffled order of your original test set.
###       In this case, you have to reorder the vector y.test in the order of 
###       increasing observation number before you make the comparison.
###       In this case, simply do:
###       
###       names(y.test) <- rownames(x.test)
###       sum(as.vector(pred.forest.rk$pred.for.obs.forest.rk) == 
###           as.vector(y.test[order(as.numeric(names(y.test)))])) / length(y.test)

